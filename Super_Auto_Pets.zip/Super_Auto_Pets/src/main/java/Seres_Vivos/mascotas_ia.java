
package Seres_Vivos;

/**
 *
 * @author Jose_Garcia:D
 */
public class mascotas_ia extends animales{
    //private int habilidad;
    
    public mascotas_ia(String Nombre, double Habilidad, int Tipo, int Tipo_Dos, int Tipo_Tres, int Tier, double Nivel, int Vida, int Agravio, int Efecto) {
        super(Nombre, Habilidad, Tipo, Tipo_Dos, Tipo_Tres, Tier, Nivel, Vida, Agravio, Efecto);
        //this.habilidad=habilidad;
    }
    
    
    
}
