
package Sujetos;

/**
 *
 * @author Jose_Garcia :D
 */
public class ia extends sujeto{
    
    public void ia(){
        
    }
    
    
}
