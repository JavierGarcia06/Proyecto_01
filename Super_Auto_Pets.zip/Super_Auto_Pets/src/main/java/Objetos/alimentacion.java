
package Objetos;

/**
 *
 * @author Usuario
 */
public class alimentacion extends comida{
    
    public alimentacion(String Nombre, int Tier, int Dar_Vida, int Dar_Agravio, int Dar_Nivel, int Tipo_Efecto) {
        super(Nombre, Tier, Dar_Vida, Dar_Agravio, Dar_Nivel, Tipo_Efecto);
    }
    
    
    
    
}
