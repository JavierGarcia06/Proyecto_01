
package Inicio;

public class principio {

    public static void main(String[] args) throws InterruptedException {
        Menu menu=new Menu();
       menu.Iniciar();
    }
    
}
